export const environment = {
    dev: '.env',
    prod: '.env.prod',
};

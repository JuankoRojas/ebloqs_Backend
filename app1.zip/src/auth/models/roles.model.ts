export enum Role {
    CUSTOMER = 'customer',
    ADMIN = 'admin',
    PRO = 'pro',
}


       export default interface AppleAuthConfig {
            client_id: string;
            team_id: string;
            redirect_uri: string;
            key_id: string;
            scope: string;
          }
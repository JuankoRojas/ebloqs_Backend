# This is the Eblooqs Backend

when us run local use the docker-compose for the database up.

for the run this proyect:

**sudo npm run start:dev**

